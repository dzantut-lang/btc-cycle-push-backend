# BTC Cycle Desk — Push Backend

Backend de referência para notificações Web Push do **BTC Cycle Desk — by Daniel Meneghelli**.

## O que faz
- Guarda inscrições Web Push dos navegadores.
- Envia notificações para os inscritos.
- Consulta a API pública da Binance a cada 15 minutos (ajustável) e alerta quando o sinal heurístico do servidor muda entre `COMPRA POTENCIAL`, `AGUARDAR` e `VENDA POTENCIAL`.
- Expõe `/health`, `/api/push/public-key`, `/api/push/subscribe`, `/api/push/unsubscribe`, `/api/market/signal` e endpoints administrativos protegidos.
- Não executa ordens e não usa chaves de trading.

**Importante:** o monitor de servidor usa uma heurística simplificada própria (EMA20/EMA50, RSI e volume). Ela pode divergir do score detalhado exibido no dashboard. Trate como alerta informativo, não recomendação de investimento.

## Variáveis de ambiente
Copie `.env.example` para `.env` e configure:
- `VAPID_PUBLIC_KEY` e `VAPID_PRIVATE_KEY` — gere com `npx web-push generate-vapid-keys`.
- `VAPID_SUBJECT` — `mailto:` de contato.
- `ADMIN_SECRET` — segredo longo e aleatório.
- `ALLOWED_ORIGIN` — URL pública exata do dashboard Wix.
- `PORT` — fornecido automaticamente por muitos hosts.
- `POLL_MINUTES` — mínimo de 5 minutos.

Não publique `.env` nem exponha a chave privada VAPID ou `ADMIN_SECRET` no frontend.

## Rodar localmente
```bash
npm install
cp .env.example .env
npx web-push generate-vapid-keys
# Cole as chaves geradas no .env
npm start
```
Abra `http://localhost:8080/health` para verificar o serviço.

## Hospedagem
Implante este diretório como serviço Node.js em um host HTTPS que mantenha o processo ativo e ofereça armazenamento persistente para `data/`. Configure as variáveis acima no painel do host. O backend precisa permanecer ligado para monitorar o mercado em segundo plano.

## Integração com o dashboard Wix
Depois de implantar, configure no `index.html` do dashboard:
- `PUSH_API_BASE`: URL HTTPS pública do backend, sem barra final.
- `PUSH_VAPID_PUBLIC_KEY`: chave pública VAPID.

O site já possui `sw.js` com tratamento de eventos `push` e clique nas notificações. A permissão do navegador precisa ser concedida pelo usuário; em iPhone, Web Push normalmente exige que o site seja adicionado à Tela de Início e aberto como web app, além de uma versão compatível do iOS.

## Eventos administrativos
Use `Authorization: Bearer <ADMIN_SECRET>` para `/api/admin/notify` e `/api/admin/check-now`. Nunca coloque esse segredo no HTML público. O endpoint manual é destinado a automações servidor-servidor, não ao navegador.
